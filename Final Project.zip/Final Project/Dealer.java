/**********************************************************
 * Program Name   : Dealer.java
 * Author         : Michael Feuerstein
 * Date           : May 17, 2012
 * Course/Section : CSC 112-001
 * Program Description: Creates and manages a virtual deck
 *     of 52 cards.
 *
 **********************************************************/

/*
     UML Diagram
     -----------
     Class Name: IntElement
     ---------------------------
     Class Variables :
     -deckSize: int
     -deck: int[]
     -top: int
     -rdm: Random
     -deck2: UnorderedArrayList
     ---------------
     Class Methods :
     +Dealer()
     +IntElement(int)
     +IntElement(IntElement)
     +setNum(int): void
     +getNum(): int
     +equals(DataElement): boolean
     +compareTo(DataElement): int
     +makeCopy(DataElement): void
     +getCopy(): DataElement
     +toString(): String
*/

import java.util.Random;
import java.util.Scanner;

public class Dealer
{
	final int DEFAULT_SIZE = 52;    //Default deck size

    private int deckSize;           //Deck size
    private int deck[];             //shuffled deck
    private int top;                //Top card of the deck/ next card to be dealt
    private Random rdm;             //shuffle randomizer
    private UnorderedArrayList baseDeck; //Storage for all the cards in the deck


        //Default Constructor,
        //sets deckSize to 52
    public Dealer()
    {
            //Set the deck size to default size
        deckSize = DEFAULT_SIZE;

            //Init top to 0
        top = 0;

            //Init Randomizer
        rdm = new Random();

            //Init card storage
		baseDeck = new UnorderedArrayList(deckSize);

            //Add cards to storage
        for(int i = 0; i < deckSize; i++)
        {
			baseDeck.insertEnd(new IntElement(i + 1));
	    }
            //Shuffle the deck
        shuffle();
    }
        //Set Constructor,
        //sets deckSize to given value
    public Dealer(int size)
    {
            //Set the deck size to given size
        deckSize = size;

            //Init top to 0
        top = 0;

            //Init Randomizer
        rdm = new Random();

            //Init card storage
		baseDeck = new UnorderedArrayList(deckSize);

            //Add cards to storage
        for(int i = 0; i < deckSize; i++)
        {
			baseDeck.insertEnd(new IntElement(i + 1));
	    }
            //Shuffle the deck
        shuffle();
    }

        //Randomly shuffles the cards in the deck
        //Takes a card from a copy of the base deck
        //and inserts it into an int array deck
    public void shuffle()
    {
		int card;    //card to be added to the deck
		int count = deckSize;  //number of cards to be added to the deck
		IntElement tempNum = new IntElement(); //IntElement of the card to be added
		UnorderedArrayList tempDeck = new UnorderedArrayList(baseDeck); //Copy of the base deck

		//Init top to 0
		top = 0;

		//Init int array deck to a size, count.
		deck = new int[count];

        //Insert cards into the deck
		for(int i = 0; i < deckSize; i++)
		{
			//Chooses a card randomly from the copy base deck.
			//the random number is restricted by the length of the
			//copy deck, insuring that every card will be randomly carried
			//over to int array deck by choosing a random location within the copy
			card = rdm.nextInt(count);
			tempNum = (IntElement)(tempDeck.retrieveAt(card));
			deck[i] = tempNum.getNum();

			//removing the card from the temp deck
			//decreases the array list copy length
			tempDeck.removeAt(card);
			count--;
		}
    }

        //Deals a speficied number
        //of cards
    public int[] deal(int numCards)
    {
        int cards[] = new int[numCards];  //Cards to be returned

            //For each card to be delt
        for(int i = 0; i < numCards; i++)
        {
			    //Place the card into cards array
            cards[i] = deck[top];
            top++;
        }

            //Return the array of delt cards
        return cards;
    }

        //Swaps out unwanted cards from a players hand
        //returns an int array of the new hand
    public int[] swapCards(int[] hand, OrderedArrayList trade)
    {
		int newHand[] = new int[5];  //new hand
		IntElement tempNum;          //card to be added/replaced

		trade.print();

        //compare each card in the old hand with an
        //arraylist of cards to be replaced
		for(int i = 0; i < 5; i++)
		{
			tempNum = new IntElement(hand[i]);

            //if the card at i is not in the arraylist,
            //keep the card
			if(trade.binarySearch(tempNum) < 0)

			    newHand[i] = hand[i];

            //otherwise replace the card with a
            //new one from the deck
			else
			{
				newHand[i] = deck[top];
                top++;
			}

			System.out.println(newHand[i]);
		}

		return newHand;
	}

        //Determine which player wins the current round of poker.
        //winning is determined by which player has the greater hand strength.
        //wins are determined two players at a time
    public int evaluateWinner(String player1, String player2)
    {
		Scanner p1;    //Scan of player 1 hand power
		Scanner p2;    //Scan of player 2 hand power

		String val1;   //Player one hand power digit value
		String val2;   //Player two hand power digit value

		int win = 0;   //int represesnting which player wins
		               //Player 1 = 1
		               //Player 2 = 2
		               //Tie = 0

        //As long as the hands are not the same
        //power aka a tie
		if(!(player1.equals(player2)))
		{
            //Scan in the handpowers
			p1 = new Scanner(player1);
		    p2 = new Scanner(player2);

            //Get the first values
            //Hand type values are the first values of
            //the power string where:
            //1 - high card
            //2 - pair
            //3 - two pair
            //4 - three of a kind
            //5 - straight
            //6 - flush
            //7 - full house
            //8 - four of a kind
            //9 - straight flush
            //10 - royal flush
		    val1 = p1.next();
		    val2 = p2.next();

            //Compare each players power values until
            //a winner is determined
		    while(val1 != null && val2 != null)
		    {
	            if(Integer.parseInt(val1)
		         > Integer.parseInt(val2))
		        {
		            win = 1;
		            break;
			    }

		        else if(Integer.parseInt(val1)
		              < Integer.parseInt(val2))
		        {
		            win = 2;
		            break;
		        }

                //next values after the type values
                //are the strength values
                //i.e. a "3 10 4 2" would be a three of a kind
                //with triple tens and a 4 2 kicker
		        if(p1.hasNext())
		        {
			        val1 = p1.next();
		            val2 = p2.next();
				}

				else

				    break;
			}
		}

		return win;
	}

        //Determines the hand strength of a players hand  <--- very important!
        //Notes: Making a CardElement could have aleviated
        //       a lot of tedium in this process.
        //
        //       I wasnt sure if any of this code was going to work
        //       when writing it.
        //
        //       I hate coding Aces, CardElement would have helped
        //
        //       This method is very tedious
    public String checkHand(int[] hand)
    {
		OrderedArrayList handCards = new OrderedArrayList(5);    //array of IntElement of cards
		                                                         //the numbers in the IntElements are the cards
		                                                         //original index value

		int pairOne = -1;        //first pair number
		int pairTwo = -1;        //second pair number
		int pairOneCount = 0;    //number of matching cards for the first pair
		int pairTwoCount = 0;    //number of matching cards for the second pair
		int pairCount = 0;       //Number of pairs, max 2
		int tempNum;             //Card number used for comparing two cards for whether they are part of a pair
		int tempNum2;            //Card number used for comparing two cards for whether they are part of a pair

		int flshCount = 0;       //Number of same suit cards
		int trashCount;          //umber of cards to be removed from handCards
		IntElement temp;         //IntElement for retrieving card numbers
		IntElement pairTrash[] = new IntElement[2];  //pairs to be deleyed from handCards
		IntElement jTrash[];        //trash cards
		int noPairHand[] = new int[5];
		int tempHand[] = new int[5];
		String handPower = "Default";
		boolean isFlsh = false;
		boolean isStr = false;

            //Add cards to list
        for(int i = 0; i < 5; i++)

			handCards.insert(new IntElement(hand[i]));

	        //Find any pairs
	        //lots of back and forth here,
	        //all its really doing is determing if there are any pairs,
	        //how many pairs, and what are the leftover cards
	    for(int i = 0; i < handCards.listSize(); i++)
        {
			trashCount = 0;

			jTrash = new IntElement[4];

	        temp = (IntElement)handCards.retrieveAt(i);

            tempNum = temp.getNum() % 13;

	        for(int j = i + 1; j < handCards.listSize(); j++)
	        {
	            temp = (IntElement)handCards.retrieveAt(j);

                tempNum2 = temp.getNum() % 13;

	            if(tempNum == tempNum2)
	            {
	                if(pairOne == -1)
                    {
                        pairOne = tempNum;
                        pairOneCount = 1;
                        pairTrash[0] = (IntElement)handCards.retrieveAt(i);
				    }

				    else if(pairTwo == -1 && pairOne != tempNum)
                    {
                        pairTwo = tempNum;
                        pairTwoCount = 1;
                        pairTrash[1] = (IntElement)handCards.retrieveAt(i);
				    }
			    }

			    if(tempNum2 == pairOne)
			    {
    				pairOneCount++;
    				jTrash[trashCount] = (IntElement)handCards.retrieveAt(j);
    				trashCount++;
				}

    			else if(tempNum2 == pairTwo)
                {
    				pairTwoCount++;
    				jTrash[trashCount] = (IntElement)handCards.retrieveAt(j);
    				trashCount++;
				}
		    }

    		for(int k = 0; k < trashCount; k++)
    		{
    		    handCards.remove(jTrash[k]);
			}
		}

		//Remove any pair numbers from the list
		if(pairOne != -1)

		    handCards.remove(pairTrash[0]);

		if(pairTwo != -1)

		    handCards.remove(pairTrash[1]);

		//Convert the leftover numbers/kickers to their card strength values
	    for(int i = 0; i < handCards.listSize(); i++)
		{
			temp = (IntElement)handCards.retrieveAt(i);

			temp.setNum(temp.getNum() % 13);

            //modify aces and kings
            if(temp.getNum() == 0)

                temp.setNum(13);

            if(temp.getNum() == 1)

                temp.setNum(14);

			handCards.replaceAt(i, temp.getCopy());
		}

		//reverse the order so that high cards are first
		handCards.reverseSort();

		//Convert the leftover kickers cards to ints
	    for(int i = 0; i < handCards.listSize(); i++)
		{
			temp = (IntElement)handCards.retrieveAt(i);

			noPairHand[i] = (temp.getNum());

		}

		//Check if there are no pairs
		if(handCards.listSize() == 5)
        {
		    //Straight
            for(int i = 0; i < 4; i++)
            {
                if(!(noPairHand[i] ==
                    (noPairHand[i + 1] + 1)))

                    break;

                //If all the cards are in sequence
                if(i == 3)

                    isStr = true;
		    }

		    //ace straight
		    if(noPairHand[0] == 14 && noPairHand[1] == 5
		       && noPairHand[2] == 4 &&  noPairHand[3] == 3 &&
		       noPairHand[4] == 2)
		    {

		       //hand is an ace straight
		       isStr = true;

		       //change the highest card to the
		       //card after the ace - will always be 5
		       noPairHand[0] = noPairHand[1];

            }

		    //Flush
            for(int i = 1; i < 5; i++)

				if(hand[0] / 14 == hand[i] / 14)

					flshCount++;

			if(flshCount == 4)

			    isFlsh = true;

            //If the hand is an straight
            //then calculate the hand power
            //for a straight
			if(isStr == true && isFlsh == false)

                handPower = "4 " + noPairHand[0];

            //Else If the hand is an flush
            //then calculate the hand power
            //for a flush
            else if(isStr == false && isFlsh == true)
 			{
				handPower = "5";

 				for(int i = 0; i < 5; i++)
					 handPower += " " + noPairHand[i];
			}

            //Else If the hand is an str/ryl flush
            //then calculate the hand power
            //for a str/ryl flush
            else if(isStr == true && isFlsh == true)
 			{
				//If the hand is a royal flush
				if(noPairHand[0] == 14 && noPairHand[1] == 13
		           && noPairHand[2] == 12 &&  noPairHand[3] == 11 &&
		           noPairHand[4] == 10)

                    handPower = "9";

                //else is straight flush
                else
                    handPower = "8 " + noPairHand[0];
			}

		    //High Card
		    else
		    {
			    handPower = "1";

 			    for(int i = 0; i < 5; i++)
					 handPower += " " + noPairHand[i];
		    }
        }
		//There are pairs
		else
        {
            //modify aces and kings
            if(pairOne == 0)

                pairOne = 13;

            if(pairOne == 1)

                pairOne = 14;

	        //One pair
            if(pairOne != -1 && pairTwo == -1)
            {
				//if()

                //Pair
                if(pairOneCount == 2)
                {
				    handPower = "2 " + pairOne;

 				    for(int i = 0; i < 3; i++)

					    handPower += " " + noPairHand[i];
		    	}

                //Three of a kind
                else if(pairOneCount == 3)
                {
				    handPower = "4 " + pairOne;
				}

                //Four of a kind
                else if(pairOneCount == 4)
                {
				    handPower = "7 " + pairOne;
				}

			}

		    //Two pair
		    if(pairOne != -1 && pairTwo != -1)
            {
                //Modify the second pair
                if(pairOne == 0)

                    pairOne = 13;

                if(pairOne == 1)

                    pairOne = 14;

                //Two pair  //one kickers
                if(pairOneCount == 2 && pairTwoCount == 2)
                {
                    if(pairOne > pairTwo)

					    handPower = "3 " + pairOne + " " + pairTwo
                                  + " " + noPairHand[0];

                    else if(pairOne < pairTwo)

					    handPower = "3 " + pairTwo + " " + pairOne
                                  + " " + noPairHand[0];
				}

		        //Full House
		        else if(pairOneCount == 3 || pairTwoCount == 3)
		        {
		            if(pairOneCount == 3)

					    handPower = "6 " + pairOne + " " + pairTwo;

					else if(pairTwoCount == 3)

					    handPower = "6 " + pairTwo + " " + pairOne;
				}
			}
		}

    return handPower;

	}
}