/**********************************************************
 * Program Name   : Opponenet.java
 * Author         : Michael Feuerstein
 * Date           : May 17, 2012
 * Course/Section : CSC 112-001
 * Program Description: Creates and manages an AI poker
 *    player and their chips.
 *
 **********************************************************/

/*
     UML Diagram
     -----------
     Class Name: Opponent
     --------------------
     Class Variables :
     -numChips: int
     -gameAnte: int
     -lost: boolean
     -parent: PokerPanel
     ---------------
     Class Methods :
     +Opponent(PokerPanel)
     +Opponent(PokerPanel, int, int)
     +getAnte(): int
     +firstBet(String, int): int
     +secondBet(String, int): int
     +bet(int): int
     +opTradeIn(int[], String, JPanel):
     +chipCount(): int
     +win(int): int
*/

import java.util.Scanner;
import java.awt.*;
import javax.swing.*;

public class Opponent
{
    private int numChips;
    private int gameAnte;
    private boolean lost;

    private PokerPanel parent;

        //Default constructor
    public Opponent(PokerPanel parent)
    {
        //set up the PokerPanel as the parent to access data
        this.parent = parent;

	    numChips = 1000;
	    gameAnte = 25;
    }

        //Set constructor
    public Opponent(PokerPanel parent, int buyIn, int anteNum)
    {
        //set up the PokerPanel as the parent to access data
        this.parent = parent;

	    numChips = buyIn;
	    gameAnte = anteNum;
    }

        //Collects the ante from the opponent
    public int getAnte()
    {
	    int ante = 0;

	    if(!lost)
	    {
            numChips -= gameAnte;
	        ante = gameAnte;
	    }

	    return ante;
    }

        //Evaluates how the AI should play their first bet
    public int firstBet(String hand, int amountBet)
    {
		Scanner handStrength = new Scanner(hand);
		String value;
		int move = 0;

		value = handStrength.next();

		if(value.equals("1"))
		{
		    value = handStrength.next();

		    if(Integer.parseInt(value) < 10 || (parent.highBet >= 300 && amountBet < 100))

		        move = -1;

		    else

		        move = 0;
		}

		else

		    move = 100;

		return move;
	}

        //Evaluates how the AI should play their second bet
	public int secondBet(String hand, int amountBet)
	{
		Scanner handStrength = new Scanner(hand);
		String value;
		int move = 0;

		value = handStrength.next();

		if(value.equals("1"))
		{

		    value = handStrength.next();

		    if(Integer.parseInt(value) < 13 || (parent.highBet >= 100 && amountBet < 100))

		        move = -1;

		    else

		        move = 0;
		}

		if(value.equals("2"))
		{
		    value = handStrength.next();

		    if(Integer.parseInt(value) < 8 || (parent.highBet >= 400 && amountBet < 100))

		        move = -1;

		    else if(Integer.parseInt(value) >= 13)

		        move = 0;
		}

		else
		{
		    move = 400;
		}
		return move;
	}

        //Makes a wager from the Ai's chipCount
    public int bet(int chipsBet)
    {
		if(numChips - chipsBet >= 0)
            numChips -= chipsBet;

        else
            numChips = 0;

        return numChips;
    }

        //Evaluates the AI's hand and determines which cards the
        //AI should discard in order to strengthen their hand
    public int[] opTradeIn(int[] hand, String handPower, JPanel player)
    {
		OrderedArrayList trashCards = new OrderedArrayList(5);

		Scanner handStrength = new Scanner(handPower);
		String value;
		int tempNum = 0;

		value = handStrength.next();

		//if(value.equals("1"))
		//{
		    value = handStrength.next();

		    System.out.println("Val Card " + value);

		    for(int i = 0; i < 5; i++)
		    {
				tempNum = hand[i] % 13;

                //modify aces and kings
                if(tempNum == 0)

                    tempNum = 13;

                if(tempNum == 1)

                    tempNum =4;

				if(tempNum != Integer.parseInt(value))

				    trashCards.insertEnd(new IntElement(hand[i]));
			}

			trashCards.print();
		//}

		return parent.tradeIn(hand, trashCards, player);
	}

        //Returns the AI's current chipCount
    public int chipCount()
    {
		return numChips;
	}

        //Adds chips won to the AI's chipCount
    public int win(int chipsWon)      // can make into one method
    {
        numChips += chipsWon;

        return numChips;
    }

}