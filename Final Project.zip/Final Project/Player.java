/**********************************************************
 * Program Name   : Player.java
 * Author         : Michael Feuerstein
 * Date           : May 17, 2012
 * Course/Section : CSC 112-001
 * Program Description: Manages an player's poker
 *    chips.
 *
 **********************************************************/

/*
     UML Diagram
     -----------
     Class Name: Player
     ------------------
     Class Variables :
     -numChips: int
     -gameAnte: int
     -lost: boolean
     ---------------
     Class Methods :
     +Player()
     +Player(int, int)
     +getAnte(): int
     +bet(int): int
     +chipCount(): int
     +win(int): int
*/

public class Player
{
    private int numChips;
    private int gameAnte;
    private boolean lost;

        //Default constructor
    public Player()
    {
		 numChips = 1000;
		 gameAnte = 25;
    }

        //Set constructor
    public Player(int buyIn, int anteNum)
    {
		 numChips = buyIn;
		 gameAnte = anteNum;
    }

        //Collects the ante from the player
    public int getAnte()
    {
		int ante = 0;

		if(!lost)
		{
            numChips -= gameAnte;
		    ante = gameAnte;
		}

		return ante;
    }

        //Makes a wager from the player's chipCount
    public int bet(int chipsBet)
    {
		if(numChips - chipsBet >= 0)
            numChips -= chipsBet;

        else
            numChips = 0;

        return numChips;
    }

        //Returns the player's current chipCount
    public int chipCount()
    {
		return numChips;
	}

        //Adds chips won to the chipCount
    public int win(int chipsWon)
    {
        numChips += chipsWon;

        return numChips;
    }

}