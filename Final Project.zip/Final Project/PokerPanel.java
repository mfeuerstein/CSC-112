/**********************************************************
 * Program Name   : PokerPanel.java
 * Author         : Michael Feuerstein
 * Date           : May 17, 2012
 * Course/Section : CSC 112-001
 * Program Description:  Creates and runs a GUI version
 *     of a five card draw poker game.
 *
 **********************************************************/

/*
     UML Diagram
     -----------
     Class Name: PokerPanel
     ----------------------
     Class Variables :
     -deckImagesV: JLabel[]
     -deckImagesH: JLabel []
     -card: ImageIcon
     -Winner: JLabel
     -handPower1: JLabel
     -handPower2: JLabel
     -handPower3: JLabel
     -handPower4: JLabel
     -p1: JPanel
     -p2: JPanel
     -p3: JPanel
     -p4: JPanel
     -win: JPanel
     -table: JPanel
     -cover: JPanel
     -buttonPanel: JPanel
     -gameScreen: JPanel
     -testB: JButton
     -tradeInB: JButton
     -betB: JButton
     -callB: JButton
     -foldB: JButton
     -nextRound: JButton
     -bListener: ButtonListener
     -cListener: CardListener
     -dlr: Dealer
     -human: Player
     -ai1: Opponent
     -ai2: Opponent
     -ai3: Opponent
     -hand1: int[]
     -hand2: int[]
     -hand3: int[]
     -hand4: int[]
     -text: TextArea
     -cards: boolean[]
     -boolean covered[]
     -coverV: ImageIcon
     -coverH: ImageIcon
     -trades: OrderedArrayList
     -handC:Cursor
     -p1Cards: JLabel[]
     -p1Cover: JLabel[]
     -pot: int
     -betTurn: int
     -startingBet: int
     +highBet: int
     -stillIn[]: boolean
     -roundCount: int
     -amountBet: int[]
     -lost: boolean[]
     -lostNum: int
     -folded: boolean[]
     -callCount: int
     -inCount: int
     -foldCount: int
     -bet2: boolean
     -seeCardsCheat: boolean
     ---------------
     Class Methods :
     +main(String[]): static void

     Program Logic - Constructor
     ---------------------------
     1.  Set up the JPanels
     2.  Load all the card images
     3.  Set up and init the hand cursor
     4.  Set up and init the text area
     5.  Set up the JButtons
     6.  Add the GUI elements the panels
     7.  Init HandPower Jlabels
     8.  Init player and Ai managers
     9.  Init the player lost booleans
     10. Init the rest of the variables

     Program Logic - StartPhase
     --------------------------
     1.  Increment and display the round count
     2.  Init pot, highBet, winner Label, fold count,
         bet round checker and card reveal button
     3.  Get ante from each player
     4.  Shuffle the deck
     5.  Remove the previous round hands
     6.  Get new hands for each player
     7.  Cover opponents hands
     8.  Determine each player's hand power
     9.  Init stillIn, amountBet and
         the startingBet

     Program Logic - betPhase
     ------------------------
     1.  Init bet turn if needed
     2.  Check if all of the players who are still in have called
         a) Post first bet: Go to the tradePhase
         b) Post Second Bet: go to the WinPhase
     3.  Otherwise start the bet loop
         a) Player's turn - Buttons turn on
         b) AI's turn - AI evaluates and acts accordingly - still stupid
         c) Account for for players who have folded,
            advance the turnCount

     Program Logic - tradePhase
     --------------------------
     1.  Add trade phase title to text area
     2.  Init turn count
     3.  Trade in Ai's cards
     4.  Enable player to trade in cards
         Betting continues after
         cards are traded

     Program Logic - winPhase
     ------------------------
     1.  Get new handPowers
     2.  Reveal opponents hand
     3.  Determine the winner
     4.  Disable the trade button
     5.  Enable the next turn button
         Wait until next round starts

     Program Logic - getHand
     -----------------------
     1.  Get a new hand from the dealer
     2.  Display the hand on the GUI

     Program Logic - tradeIn
     -----------------------
     1.  Init updated card hand
     2.  Remove the old cards from the player panel
     3.  Get new cards from the dealer
     4.  Re-display the new hand on the GUI

     Program Logic - coverHand
     -------------------------
     1.  Determine whether the opponents hands
         are already covered
         a) uncovered: cover the hands
         b) covered: uncover the cards

     Program Logic - coverCard
     -------------------------
     1.  Remove the player's cards from the panel
     2.  Determine which card needs to be covered
     3.  Cover/Uncover the card

     Program Logic - getWinner
     -------------------------
     1.  Init winner, winString,
         and winCount
     2.  Init the ties OrderedArrayList
     3.  Init String array of hand powers
     4.  Compare each hand power to every other hand power
     5.  Determine a winner

     Program Logic - ButtonLister
     ----------------------------
     1.  Press see Opponent cards button
            a) cover/uncover opponents cards
     2.  Press the tradeIn button
            a) trade in all covered player's cards
            b) advance to betround 2
     3.  Press the betB button
            a) Raise the current bet by 100 and go
               to the next better
     4.  Press the callB button
            a) Call the current bet and go
               to the next better
     5.  Press the foldB button
            a) Fold the hand and go
               to the next better
     6.  Pres the nextRound button
            a) start the next poker round

     Program Logic - MouseListener
     -----------------------------
     1.  Cover up cards to be traded in

*/

import java.io.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PokerPanel extends JPanel
{
    private JLabel deckImagesV[];      //Labels of every vertical card image
    private JLabel deckImagesH[];      //Labels of every horizontal card image
    private ImageIcon card;            //card image
    private JLabel Winner, handPower1, handPower2,
                           handPower3, handPower4;  //String representation of a players hand's power ranking
    private JPanel p1, p2, p3, p4, win, table, cover, buttonPanel, gameScreen;  //JPanels
    private JButton testB, tradeInB, betB, callB, foldB, nextRound;             //JButtons
    private ButtonListener bListener;     //Button Listener
    private CardListener cListener;       //mouse listerner for covering player cards
    private Dealer dlr;                   //Instantiation of the dealer class
    private Player human;                 //human player manager
    private Opponent ai1;                 //AI 1 manager
    private Opponent ai2;                 //AI 2 manager
    private Opponent ai3;                 //AI 3 manager
    private int hand1[];                  //Player 1's hand
    private int hand2[];                  //AI 1's hand
    private int hand3[];                  //AI 2's hand
    private int hand4[];                  //AI 3's hand
    private TextArea text;                //text area detailing events in the game
    private boolean cards[] = {false,false,false,false,false};    //boolean array of players covered card
    private boolean covered[] = {false,false,false,false};        //array of opponents covered hands
    private ImageIcon coverV = new ImageIcon("cards/0.gif");      //image of a vertical card back
    private ImageIcon coverH = new ImageIcon("cards/53.gif");     //image of a horizontal card back
    private OrderedArrayList trades = new OrderedArrayList(5);    //player's cards that are covered, covered cardscan be traded in for new cards
    private Cursor handC;      //cursor style for JLabel links
    private JLabel p1Cards[] = new JLabel[5];    //player 1's cards, used to cover the player's cards
    private JLabel p1Cover[] = new JLabel[5];    //player 1's covered cards, used to uncover player's cards
    private int pot;           //chip pot
    private int betTurn;       //counter which determines who bets next
    private int startingBet;   //Starting bet of the round
    public int highBet;        //current high bid of the betting phase
    private boolean stillIn[]; //boolean array of which players are still in: called, made a bet, all in
    private int roundCount;    //count of the number of rounds
    private int amountBet[];   //amount of chips each player has put into the pot
    private boolean lost[];    //array of which players have lost
    private int lostNum;       //num to determine still in count
    private boolean folded[];  //boolean array of which players have folded the round
    private int callCount;     //count of how many players have called
    private int inCount;       //count of how many player are still in
    private int foldCount;     //count of how many players have folded
    private boolean bet2;      //determines which bet phase it is
    private boolean seeCardsCheat; //determines whether player 1 is a dirty cheater

    public PokerPanel()
    {
		//Set up the JPanels

		    //Set up the main panel as a border layout
		setLayout (new BorderLayout(1, 2));
		setForeground(Color.blue);
        setPreferredSize (new Dimension(810, 700));

           //Set up the gameScreen as a border layout
           //contains the table and buttonpanel
        gameScreen = new JPanel();
		gameScreen.setLayout (new BorderLayout());
		gameScreen.setBackground(Color.green);
        gameScreen.setPreferredSize (new Dimension(650, 700));

           //Set up the table as a border layout
           //contains the players and win label
        table = new JPanel();
		table.setLayout (new BorderLayout());
		table.setBackground(Color.green);
        table.setPreferredSize (new Dimension(650, 700));

            //Set up the buttonPanel as a flow layout
            //contains all of the player buttons
        buttonPanel = new JPanel();
		buttonPanel.setLayout (new FlowLayout());
		buttonPanel.setBackground(Color.green);
        //buttonPanel.setPreferredSize (new Dimension(650, 50));

            //Contains wining player label
        win = new JPanel();
        win.setPreferredSize(new Dimension(200, 200));

            //Sets up each player panel
            //each panel includes their respective player's
            //card hands
            //Panels use a grid layout
        p1 = new JPanel();
        p1.setLayout(new GridLayout(1, 5));
        p1.setCursor(handC);
        p1.setName("Player 1");

        p2 = new JPanel();
        p2.setLayout(new GridLayout(5, 1));
        p2.setName("Player 2");

        p3 = new JPanel();
        p3.setLayout(new GridLayout(1, 5));
        p3.setName("Player 3");

        p4 = new JPanel();
        p4.setLayout(new GridLayout(5, 1));
        p4.setName("Player 4");

        //Load all the card images
        deckImagesV = new JLabel[53];
        deckImagesH = new JLabel[53];
        dlr = new Dealer();

                cListener = new CardListener();

            //set each image to a JLabel
        for(int i = 0; i < 53; i++)
        {
            card = new ImageIcon("cards/" + i + ".gif");
            deckImagesV[i] = new JLabel(card);
            deckImagesV[i].setName("" + i);

            card = new ImageIcon("cards/" + (i + 53) + ".gif");
            deckImagesH[i] = new JLabel(card);
            deckImagesH[i].setName("" + i);
        }

        //Initialize hand Cursor
        handC = new Cursor(Cursor.HAND_CURSOR);

            //Set up the player's cover cards
        for(int i = 0; i < 5; i++)
        {
            p1Cover[i] = new JLabel(coverV);
            p1Cover[i].addMouseListener(cListener);
            p1Cover[i].setCursor(handC);

            p1Cards[i] = new JLabel(coverV);
            p1Cards[i].addMouseListener(cListener);
            p1Cards[i].setCursor(handC);
        }

        //set up the text area
        text = new TextArea(300,20);
        text.setEditable(false);

        //Set up the winnner JLabel
        Winner = new JLabel();
        Winner.setLocation(80,80);

        //init the buttonLister
        bListener = new ButtonListener();

        //Setup buttons
        testB = new JButton("Cheat");
        testB.setLocation(80,300);
        testB.addActionListener(bListener);

            //Trade cards in button
        tradeInB = new JButton("Trade In");
        tradeInB.setEnabled(false);
        tradeInB.addActionListener(bListener);

            //bet Button
        betB = new JButton("100");
        betB.setEnabled(false);
        betB.addActionListener(bListener);

            //call Button
        callB = new JButton("Call");
        callB.setEnabled(false);
        callB.addActionListener(bListener);

            //fold Button
        foldB = new JButton("Fold");
        foldB.setEnabled(false);
        foldB.addActionListener(bListener);

             //next round Button
        nextRound = new JButton("Next Round");
        nextRound.setEnabled(false);
        nextRound.addActionListener(bListener);

        //Add the GUI elements the panels
        win.add(Winner);

            //add the buttons to the buttonpanel
        buttonPanel.add(testB);
        buttonPanel.add(tradeInB);
        buttonPanel.add(betB);
        buttonPanel.add(callB);
        buttonPanel.add(foldB);
        buttonPanel.add(nextRound);

            //Add the players and win panel
            //to the table
        table.add (p1, BorderLayout.SOUTH);
        table.add (p2, BorderLayout.WEST);
        table.add (p3, BorderLayout.NORTH);
        table.add (p4, BorderLayout.EAST);
        table.add (win, BorderLayout.CENTER);

            //Add the table and the buttons to the
            //gameScreen
        gameScreen.add(table, BorderLayout.CENTER);
        gameScreen.add(buttonPanel,  BorderLayout.SOUTH);

            //Add the game screen and the text area
            //to the main panel
        add(gameScreen, BorderLayout.CENTER);
        add(text,  BorderLayout.EAST);

        //Init hand power JLabels
        //Note: could make into strings
        handPower1 = new JLabel();
        handPower2 = new JLabel();
        handPower3 = new JLabel();
        handPower4 = new JLabel();

        //Init player and Ai managers
        human = new Player();
        ai1 = new Opponent(this);
        ai2 = new Opponent(this);
        ai3 = new Opponent(this);

        //Init player lost boolean
        lost = new boolean[4];
        lost[0] = false;
        lost[1] = false;
        lost[2] = false;
        lost[3] = false;

        //Init the rest of the variables
        amountBet = new int[4];
        betTurn = 0;
        startingBet = 0;
        highBet = 0;
        stillIn = new boolean[4];
        folded = new boolean[4];
        roundCount = 0;
        lostNum = 0;
        seeCardsCheat = false;

        startPhase();
    }

        //Starts a new poker round
        //Inits all neccessary variables
        //and get each player a new hand
    private void startPhase()
    {
        //Increment and display the round count
        roundCount++;

		text.append("\n----------------------------------\n");
        text.append("Round " + roundCount);
        text.append("\n----------------------------------\n");

        //Init the pot
        pot = 0;

        //Init highbet
        highBet = 0;

        //Init winner label
        Winner.setText("");

        //Init fold count
        foldCount = 0;
        callCount = 0;
        inCount = 4 - lostNum;

        //Init bet round checker
        bet2 = false;

        //Init card reveal button
        testB.setEnabled(true);

        //Get ante from each player
        pot += human.getAnte();
        pot += ai1.getAnte();
        pot += ai2.getAnte();
        pot += ai3.getAnte();

		//Shuffle the deck
		dlr.shuffle();

        //Remove the previous card hands
        p1.removeAll();
        p2.removeAll();
        p3.removeAll();
        p4.removeAll();

        updateUI();

        //Get a new hand for each player
        hand1 = getHand(5,p1);
        hand2 = getHand(5,p2);
        hand3 = getHand(5,p3);
        hand4 = getHand(5,p4);

        //Check to see whether card reveal cheat is on
        if(!seeCardsCheat)
        {
            covered[1] = coverHand(hand2, p2, covered[1]);
            covered[2] = coverHand(hand3, p3, covered[2]);
            covered[3] = coverHand(hand4, p4, covered[3]);
		}

        updateUI();

        //Determine each player's hand power
        handPower1.setText(dlr.checkHand(hand1));
        handPower2.setText(dlr.checkHand(hand2));
        handPower3.setText(dlr.checkHand(hand3));
        handPower4.setText(dlr.checkHand(hand4));

        //init still in booleans
        //init amount bets
        for(int i = 0; i < 4; i++)
        {
			amountBet[i] = 0;

			if(lost[i] == false)
			{
				folded[i] = false;
                stillIn[i] = true;
			}
		}

        //Init starting bet
        if(startingBet > 3)

            startingBet = 0;

        betTurn = startingBet;

        text.append("\nFirst Bet\n");

        //Go to the first bet phase
        betPhase(highBet);
	}

        //Wager round, each player can make a wager,
        //call or fold. The method loops using recursion
	public void betPhase(int bet)
	{
		//Init bet turn if needed
        if(betTurn > 3)

            betTurn = 0;

        //Everyone has called
        if(inCount == callCount)
        {
			//Go to tradePhase if the betPhase
			//was the first bet
            if(bet2 == false)
            {
                //trade in round
                tradePhase();

                //set bet2 to true
                bet2 = true;
		    }

            //Else the betPhase was the second bet
            //advance to the winPhase
            else

                winPhase();
		}

        //Start the bet loop
        else
        {

            //if its player 1's turn
            //turn on the betting buttons
            //betting will continue after
            //a betting button is pressed
            if(betTurn == 0 && stillIn[0])
            {
                betB.setEnabled(true);
                callB.setEnabled(true);
                foldB.setEnabled(true);
		    }

            //Else its the AI"s turn
            //Determine the actions for each AI
            //Call
            //Fold
            //Bet
            else if(betTurn == 1 && stillIn[1])
            {
		    	if(foldCount == 1)
                {
		    	    stillIn[1] = false;
			        folded[1] = true;
			        foldCount++;
			        inCount--;
			        text.append("\nPlayer 2 folds");
				}

				else if(callCount > 0 || ai1.chipCount() == 0)
				{
			    	if(ai1.bet(highBet) > 0)
			    	{
			    	    pot += highBet - amountBet[1];
			    	    amountBet[1] = highBet;
					}

				    try
				    {
					    Thread.sleep(1000);

				    }

				    catch(InterruptedException ie){}

				    text.append("\nPlayer 2 Calls");

				    betTurn++;
				    callCount++;

				    betPhase(highBet);
				}

				else
				{
				    highBet += 100;
				    ai1.bet(highBet);
				    pot += highBet;

			    	try
			    	{
					    Thread.sleep(1000);

			    	}

			    	catch(InterruptedException ie){}

			    	text.append("\nPlayer 2 bets " + highBet);

			    	betTurn++;

			    	betPhase(highBet);
				}
			}

        	else if(betTurn == 2 && stillIn[2])
        	{
				if(foldCount == 90)
            	{
			    	stillIn[2] = false;
			    	folded[2] = true;
			    	foldCount++;
			    	inCount--;
			    	text.append("\nPlayer 3 folds");
				}

				else if(callCount > 0 || ai2.chipCount() == 0)
				{
			    	if(ai2.chipCount() > 0)
			    	{
			    	    pot += highBet - amountBet[2];
			    	    amountBet[2] = highBet;
					}

			    	try
			    	{
				    	Thread.sleep(1000);

			    	}

			    	catch(InterruptedException ie){}

			    	text.append("\nPlayer 3 Calls");

			    	betTurn++;
			    	callCount++;

			    	betPhase(highBet);
				}

				else
				{
			    	highBet += 100;
			    	ai2.bet(highBet);
			    	pot += highBet;

			    	try
			    	{
				    	Thread.sleep(1000);

			    	}

			    	catch(InterruptedException ie){}

			    	text.append("\nPlayer 3 bets " + highBet);

			    	betTurn++;

			    	betPhase(highBet);
				}
			}

        	else if(betTurn == 3 && stillIn[3])
        	{
				if(foldCount == 90)
            	{
			    	stillIn[3] = false;
			    	folded[3] = true;
			    	foldCount++;
			    	inCount--;
			    	text.append("\nPlayer 4 folds");
				}

				else if(callCount > 0 || ai3.chipCount() == 0)
				{
			    	if(ai3.bet(highBet) > 0)
			    	{
			    	    pot += highBet - amountBet[3];
			    	    amountBet[3] = highBet;
					}

			    	try
			    	{
				    	Thread.sleep(1000);

			    	}

			    	catch(InterruptedException ie){}

			    	text.append("\nPlayer 4 Calls");

			    	betTurn++;
			    	callCount++;

			    	betPhase(highBet);
				}

				else
				{
			    	highBet += 100;
			    	ai3.bet(highBet);
			    	pot += highBet;

			    	try
			    	{
				    	Thread.sleep(1000);

			    	}

			    	catch(InterruptedException ie){}

			    	text.append("\nPlayer 4 bets " + highBet);

			    	betTurn++;

			    	betPhase(highBet);
				}
			}

            //Account for players who have folded
            //advance the betTurn ticker so that
            //the players who are stilll in can play
        	if(betTurn == 0 && !stillIn[0])
        	{
				betTurn++;
				betPhase(highBet);
			}

        	else if(betTurn == 1 && !stillIn[1])
        	{
				betTurn++;
				betPhase(highBet);
			}

        	else if(betTurn == 2 && !stillIn[2])
        	{
				betTurn++;
				betPhase(highBet);
			}

        	else if(betTurn == 3 && !stillIn[3])
        	{
				betTurn++;
				betPhase(highBet);
			}
		}
	}

        //Players can trade in their
        //unwanted cards durig this phase
	public void tradePhase()
	{
		//Add trade phase title to text area
		text.append("\n\nTrade Cards");

        //Init bet turn
		betTurn = 0;

        //Trade in opponents cards
		hand2 = ai1.opTradeIn(hand2, handPower2.getText(), p2);
		hand3 = ai3.opTradeIn(hand3, handPower3.getText(), p3);
		hand4 = ai3.opTradeIn(hand4, handPower4.getText(), p4);

        //Reveal the opponents hands
        if(!seeCardsCheat)
        {
            covered[1] = coverHand(hand2, p2, covered[1]);
            covered[2] = coverHand(hand3, p3, covered[2]);
            covered[3] = coverHand(hand4, p4, covered[3]);
		}

		updateUI();

        //Check whether the player has folded
        //Set trade in button to enabled
		if(folded[0] == false)
		{
		    tradeInB.setEnabled(true);
		}

	}

        //Determines which player wins the round
	public void winPhase()
	{
        //Determine each player's hand power
        handPower1.setText(dlr.checkHand(hand1));
        handPower2.setText(dlr.checkHand(hand2));
        handPower3.setText(dlr.checkHand(hand3));
        handPower4.setText(dlr.checkHand(hand4));

        //Reveal the opponents hands
        if(!seeCardsCheat)
        {
            covered[1] = coverHand(hand2, p2, covered[1]);
            covered[2] = coverHand(hand3, p3, covered[2]);
            covered[3] = coverHand(hand4, p4, covered[3]);
		}

		else

		    text.append("\nPlayer 1 is a cheater\n");

        updateUI();

		text.append("\n\nPlayer 1 Hand Power: " + handPower1.getText());
		text.append("\n\nPlayer 2 Hand Power: " + handPower2.getText());
		text.append("\n\nPlayer 3 Hand Power: " + handPower3.getText());
		text.append("\n\nPlayer 4 Hand Power: " + handPower4.getText());

        //Determine the winner and display the
        //round winner in the game screen
        Winner.setText("Winner \n\n" + "Player "
                       + getWinner(handPower1.getText(), handPower2.getText(),
                                   handPower3.getText(), handPower4.getText())
                       + "Wins $" + pot);

        //Turn off the trade button
        testB.setEnabled(false);

        //Enable the next turn button
        nextRound.setEnabled(true);
	}

        //Get each player a five card hand
        //Displays each hand on the GUI
    public int[] getHand(int numCards, JPanel player)
    {
		//Get a hand from the dealer
		int hand[] = dlr.deal(numCards);

        //Get player one's cards
        if(player == p1)

		    for(int i = 0; i < numCards; i++)
		    {
				p1Cards[i].setIcon(deckImagesV[hand[i]].getIcon());
				p1Cards[i].setName(deckImagesV[hand[i]].getName());
		   	    player.add(p1Cards[i]);
		    }

        //Get player three's cards
        else if(player == p3)

		    for(int i = 0; i < numCards; i++)
		    {
		   	    player.add(deckImagesV[hand[i]]);
		    }

        //Get player four's cards
		else

		    for(int i = 0; i < numCards; i++)
			{
				player.add(deckImagesH[hand[i]]);
		    }

        updateUI();

		return hand;
	}

        //Trades in unwanted cards for new ones
	public int[] tradeIn(int hand[], OrderedArrayList TradeIns, JPanel player)
	{
        text.append("\n" + player.getName() + " trades in for "  + TradeIns.listSize() + " cards");

		//init updated card hand
		int newHand[] = new int[5];

        //remove the cards from the player panel
		player.removeAll();

        //get new cards
		newHand = dlr.swapCards(hand, TradeIns);

        //display the cards on the gui for player 1 or 3
        if(player == p1 || player == p3)

		    for(int i = 0; i < 5; i++)
		    {
		   	    player.add(deckImagesV[newHand[i]]);
		    }

        //display the cards on the gui for player 2 or 4
		else

		    for(int i = 0; i < 5; i++)
			{
				player.add(deckImagesH[newHand[i]]);
		    }

		updateUI();

		return newHand;
	}

        //Covers up all of the opponents hands
        //The hands will only show the card backs
    public boolean coverHand(int hand[], JPanel player, boolean isCovered)
    {
		//Determine whther the cards are being shown or not
		//If yes, cover the cards
		if(isCovered == false)
		{
			player.removeAll();

            if(player == p3)

		        for(int i = 0; i < 5; i++)
		        {
		   	        player.add(new JLabel(coverV));
		        }

		    else

		        for(int i = 0; i < 5; i++)
			    {
				    player.add(new JLabel(coverH));
		        }

		    isCovered = true;
		}

        //else, display the cards
		else
        {
			player.removeAll();

            if(player == p3)

		        for(int i = 0; i < 5; i++)
		        {
		   	        player.add(deckImagesV[hand[i]]);
		        }

		    else if(player == p2 || player == p4)

		        for(int i = 0; i < 5; i++)
			    {
				    player.add(deckImagesH[hand[i]]);
				}

			isCovered = false;
		}

		return isCovered;
	}

        //Covers up a players specific card(s)
        //The card will only show the card back
    public void coverCard(int num)
    {
		//Remove the player's cards
		p1.removeAll();

        //Figure out which card needs to be covered
        //using the number stored in the name variable
		for(int i = 0; i < 5; i++)
		{
			if(cards[i] == false && hand1[i] == num)
			{
				p1Cover[i].setName(p1Cards[i].getName());
		   	    p1.add(p1Cover[i]);
		   	    cards[i] = true;
		    }

		   	else if(cards[i] == true && hand1[i] == num)
		   	{
		   	    p1.add(p1Cards[i]);
		   	    cards[i] = false;
		    }

		   	else if(cards[i] == true && hand1[i] != num)
			{
				p1Cover[i].setName(p1Cards[i].getName());
		   	    p1.add(p1Cover[i]);
		    }

		   	else if(cards[i] == false && hand1[i] != num)

		   	    p1.add(p1Cards[i]);
		}

	}

        //Evaluates which out of the four players has won
        //the round. Each hand will be compare to each other hand
        //and whichever hand "wins" the most times wins the round
	public String getWinner(String player1, String player2,
	                     String player3, String player4)
	{

		IntElement temp;

		//Init winner
		int winner = 0;

		//Init winString
		String winString = "";

        //Init winCount
		int winCount = 0;

		//Init OrderedArrayList of tied hands
		OrderedArrayList ties = new OrderedArrayList(4);

        //Init string array of hand powers
		String player[] = {player1, player2,
		                   player3, player4};

		text.append("\n\n");

        //Compare each hand power to every other handpower(including itself)
		for(int i = 0; i < 4; i++)
        {
			winCount = 0;
			ties.clearList();

            //Compare handpowers two at a time
			for(int j = 0; j < 4; j++)
			{
			    winner = dlr.evaluateWinner(player[i], player[j]);

                //Determine whether the hand won or not
			    if(winner == 1)

			        winCount++;

			    else if(winner == 0)

			        ties.insert(new IntElement(j + 1));
			}

            //Get the string of the winning player
			if(winCount + ties.listSize() == 4)
			{
				for(int w = 0; w < ties.listSize();w++)
				{
					temp = (IntElement)ties.retrieveAt(w);
					winString += "" + (temp.getNum()) + " ";
				}
			}
		}

		return winString;
	}

    //*****************************************************************
    //  Represents a listener for button push (action) events.
    //*****************************************************************
    private class ButtonListener implements ActionListener
    {
        //--------------------------------------------------------------
        //  Chooses an appropriate action based on the button pressed
        //--------------------------------------------------------------
        public void actionPerformed (ActionEvent event)
        {
			//If test button is pressed
			//uncover the  opponents cards
			if(event.getSource() == testB)
			{
                covered[1] = coverHand(hand2, p2, covered[1]);
                covered[2] = coverHand(hand3, p3, covered[2]);
                covered[3] = coverHand(hand4, p4, covered[3]);

                updateUI();

                if(!seeCardsCheat)

                    seeCardsCheat = true;

                else
                    seeCardsCheat = false;
			}

            //Trade in all covered player's cards
            //and enter the second bet phase
			if(event.getSource() == tradeInB)
			{
				hand1 = tradeIn(hand1, trades, p1);

				trades.clearList();

				for(int i = 0; i < 5; i++)

				    cards[i] = false;

				tradeInB.setEnabled(false);

                callCount = 0;

                text.append("\n\nSecond Bet\n");
                betPhase(0);

			}

            //Raise the bet by 100 and go
            //to the next better
			if(event.getSource() == betB)
			{
				highBet += 100;
			    human.bet(highBet);
			    pot += highBet;
			    text.append("\nPlayer 1 bets " + highBet);

			    betTurn++;

			    betB.setEnabled(false);
			    callB.setEnabled(false);
			    foldB.setEnabled(false);

			    betPhase(highBet);
			}

            //Call the current bet and go to
            //the next better
			if(event.getSource() == callB)
			{
				//stillIn[0] = false;
			    human.bet(highBet);
			    pot += highBet - amountBet[0];
			    amountBet[0] = highBet;

			    text.append("\nPlayer 1 Calls");

			    betTurn++;
			    callCount++;

			    betB.setEnabled(false);
			    callB.setEnabled(false);
			    foldB.setEnabled(false);

			    betPhase(highBet);
			}

            //Fold your hand and
            //go to the next better
			if(event.getSource() == foldB)
			{
				stillIn[0] = false;
				folded[0] = true;
				foldCount++;

			    text.append("\nPlayer 1 folds");

			    betTurn++;

			    p1.setVisible(false);

			    betB.setEnabled(false);
			    callB.setEnabled(false);
			    foldB.setEnabled(false);
			    updateUI();

			    betPhase(highBet);

			}

            //start the next round of poker
			if(event.getSource() == nextRound)
			{
				nextRound.setEnabled(false);

                startPhase();
			}

		}

	}

    //*****************************************************************
    //  Represents the listener for all mouse events.
    //*****************************************************************
    private class CardListener implements MouseListener, MouseMotionListener
    {
        private String lastText = "";     //stores the original label text

        //----------------------------------------------------------------
        //  Changes the font of the label text that mouse is hovering over
        //----------------------------------------------------------------
        public void mouseEntered (MouseEvent event){}

        //--------------------------------------------------------
        //  Determines an action depending on the label clicked on
        //--------------------------------------------------------
        public void mouseClicked (MouseEvent event)
        {

			//Cover up cards to be traded in

			//get the name of the component/player card clicked on
			IntElement tempNum = new IntElement(Integer.parseInt(event.getComponent().getName()));

                //the card is not in the array
                //The card is set to be trashed/traded in
			if(trades.binarySearch(tempNum) < 0)
			{
                trades.insert(tempNum);
                coverCard(tempNum.getNum());
			}

                //the card is in the array
                //The card is unchecked
		    else
			{
                trades.remove(tempNum);
                coverCard(tempNum.getNum());
			}

            updateUI();

        }
        public void mouseReleased (MouseEvent event) {}

        //------------------------------------------------------------------------
        //  Returns a labe's text to its previous font when no longer hovered over
        //------------------------------------------------------------------------
        public void mouseExited (MouseEvent event){}
        public void mouseMoved (MouseEvent event) {}
        public void mousePressed (MouseEvent event){}
        public void mouseDragged (MouseEvent event){}
    }
}