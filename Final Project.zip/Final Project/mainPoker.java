/**********************************************************
 * Program Name   : mainPoker.java
 * Author         : Michael Feuerstein
 * Date           : May 17, 2012
 * Course/Section : CSC 112-001
 * Program Description:  This class invokes a GUI of the
 *    PokerPanel. In essense creating a virtual poker game.
 *
 **********************************************************/

/*
     UML Diagram
     -----------
     Class Name: mainPoker
     ---------------------
     Class Variables :

     ---------------
     Class Methods :
     +main(String[]): static void

     Program Logic
     -------------
     1.  Create a new PokerPanel
     2.  Create and show a new JFrame with
         the PokerPanel as its content
*/

import javax.swing.*;

public class mainPoker
{
    public static void main(String[] args)
    {
        //Create a new PokerPanel
        PokerPanel panel = new PokerPanel();

        //Create a new JScrollPane using the
        //VideoStorePanel
	    JScrollPane pane = new JScrollPane (panel);

        //Create and show a new JFrame with
        //the PokerPanel as its content
        JFrame frame = new JFrame ("Poker");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.setContentPane(panel);
        frame.pack();
        frame.setVisible(true);
    }
}

/*

Sample Output is in "Poker Sample Output" word file

*/