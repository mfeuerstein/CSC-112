public class QueueException extends RuntimeException
{
    public QueueException()
    {
    }

    public QueueException(String msg)
    {
        super(msg);
    }
}


